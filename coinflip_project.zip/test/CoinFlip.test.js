const { expect } = require("chai");

describe("CoinFlip", function () {
    it("Should return the correct balance after a flip", async function () {
        const [owner, addr1] = await ethers.getSigners();
        const CoinFlip = await ethers.getContractFactory("CoinFlip");
        const coinFlip = await CoinFlip.deploy();
        await coinFlip.deployed();

        const initialBalance = await ethers.provider.getBalance(addr1.address);
        await coinFlip.connect(addr1).flipCoin(true, { value: ethers.utils.parseEther("1") });

        const finalBalance = await ethers.provider.getBalance(addr1.address);
        expect(finalBalance).to.not.equal(initialBalance);
    });
});
