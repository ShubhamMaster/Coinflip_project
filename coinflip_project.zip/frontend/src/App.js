import React, { useState } from "react";
import WalletConnect from "./components/WalletConnect";
import CoinFlipGame from "./components/CoinFlipGame";
import "./App.css";

function App() {
    const [provider, setProvider] = useState(null);
    const [signer, setSigner] = useState(null);

    return (
        <div className="App">
            <WalletConnect setProvider={setProvider} setSigner={setSigner} />
            <CoinFlipGame />
        </div>
    );
}

export default App;
