import React, { useState } from "react";
import { ethers } from "ethers";
import { coinFlipContract } from "../web3";

const CoinFlipGame = () => {
    const [amount, setAmount] = useState("");
    const [side, setSide] = useState(true); // true for heads, false for tails
    const [message, setMessage] = useState("");

    const flipCoin = async () => {
        try {
            const txn = await coinFlipContract.flipCoin(side, { value: ethers.utils.parseEther(amount) });
            await txn.wait();

            if (txn.events[0].args[0]) {
                setMessage("You won!");
            } else {
                setMessage("You lost!");
            }
        } catch (err) {
            setMessage("Transaction failed!");
            console.error(err);
        }
    };

    return (
        <div>
            <h1>Coin Flip Game</h1>
            <input
                type="number"
                placeholder="Amount (ETH)"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
            />
            <select onChange={(e) => setSide(e.target.value === "heads")}>
                <option value="heads">Heads</option>
                <option value="tails">Tails</option>
            </select>
            <button onClick={flipCoin}>Flip Coin</button>
            <p>{message}</p>
        </div>
    );
};

export default CoinFlipGame;
