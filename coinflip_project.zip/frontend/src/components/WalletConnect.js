import React, { useEffect } from "react";
import { ethers } from "ethers";

const WalletConnect = ({ setProvider, setSigner }) => {
    useEffect(() => {
        const connectWallet = async () => {
            const provider = new ethers.providers.Web3Provider(window.ethereum);
            const signer = provider.getSigner();
            setProvider(provider);
            setSigner(signer);
        };

        if (window.ethereum) {
            window.ethereum.request({ method: "eth_requestAccounts" });
            connectWallet();
        } else {
            alert("Install MetaMask to use this app!");
        }
    }, [setProvider, setSigner]);

    return <p>Wallet connected</p>;
};

export default WalletConnect;
