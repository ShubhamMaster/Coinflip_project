import { ethers } from "ethers";
import CoinFlip from "./artifacts/contracts/CoinFlip.sol/CoinFlip.json";

const coinFlipAddress = "<DEPLOYED_CONTRACT_ADDRESS>";

export const coinFlipContract = new ethers.Contract(coinFlipAddress, CoinFlip.abi, ethers.getDefaultProvider("ropsten"));
